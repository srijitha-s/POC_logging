from contextlib import redirect_stdout
import subprocess
import re
p = subprocess.check_output("PowerShell.exe -Executionpolicy byPass -File C:\\Users\\srijitha.s\\Downloads\\logging\\sample.ps1")
with open('out.txt', 'w') as f:
    with redirect_stdout(f):
        print(p.decode())

regex = r'ProcessID\s+:\s+(\d+)\n+Name\s+:\s+(\w.+)\n+WS\s+:\s+(\d+)\n+CommandLine\s+:\s(.+)?'

dic={}
with open ('out.txt', 'r') as infile:
    content = infile.read()
    results = re.findall(regex,content)

s=0
for i in results:
    if i[3]!='':
        match='.+'+i[1]
        s=re.search(match,i[3],re.IGNORECASE).group(0)
    dic[i[0]]=list(i[1:3])
    dic[i[0]].append(s)

print(dic)
print(len(dic))





